package com.example.predohealth;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class PredictActivity extends AppCompatActivity {

    private ImageView imageViewUploaded, imageViewResult;
    private Button btnLoadSample, btnUploadPhoto, btnSubmit;
    private TextView textViewResult;

    private static final int PICK_IMAGE = 1;
    private Uri imageUri;

    private String[] diseases = {
            "Eczema",
            "Psoriasis",
            "Skin Cancer",
            "Melanoma",
            "Dermatitis",
            "Acne",
            "Rosacea",
            "Warts",
            "Basal Cell Carcinoma"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predict);

        imageViewUploaded = findViewById(R.id.imageViewUploaded);
        imageViewResult = findViewById(R.id.imageViewResult);
        btnLoadSample = findViewById(R.id.btnLoadSample);
        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
        btnSubmit = findViewById(R.id.btnSubmit);
        textViewResult = findViewById(R.id.textViewResult);

        btnLoadSample.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadSampleImage();
            }
        });

        btnUploadPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitImage();
            }
        });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
            imageViewUploaded.setImageURI(imageUri);
        }
    }

    private void loadSampleImage() {
        // Generate a random index to select one of the nine sample images
        Random random = new Random();
        int sampleIndex = random.nextInt(9) + 1; // Assuming images are named sample1, sample2, ..., sample9

        int imageResId = getResources().getIdentifier("sample" + sampleIndex, "drawable", getPackageName());
        imageViewUploaded.setImageResource(imageResId);
        imageUri = Uri.parse("android.resource://" + getPackageName() + "/" + imageResId);
    }

    private void submitImage() {
        if (imageUri != null) {
            String predictionResult = predictDisease();
            textViewResult.setText("Disease Prediction: " + predictionResult);
            imageViewResult.setImageURI(imageUri); // Display the uploaded image as result
        } else {
            textViewResult.setText("Please load an image.");
        }
    }

    private String predictDisease() {
        // Randomly select a disease name from the predefined list
        Random random = new Random();
        int diseaseIndex = random.nextInt(diseases.length);
        return diseases[diseaseIndex];
    }
}
