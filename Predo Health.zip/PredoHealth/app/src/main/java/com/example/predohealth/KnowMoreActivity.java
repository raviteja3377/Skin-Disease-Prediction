package com.example.predohealth;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class KnowMoreActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_know_more);

        TextView textViewInfo = findViewById(R.id.textViewInfo);
        textViewInfo.setText(" Adding content Later ");
        textViewInfo.setTextColor(getResources().getColor(R.color.white));
        textViewInfo.setTextSize(24);
    }
}
