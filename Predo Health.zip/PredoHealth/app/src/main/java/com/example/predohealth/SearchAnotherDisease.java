package com.example.predohealth;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchAnotherDisease extends AppCompatActivity {

    private Map<String, String> autoCorrectMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_another_disease);

        autoCorrectMap = createAutoCorrectMap();

        EditText symptom1EditText = findViewById(R.id.editTextSymptom1);
        EditText symptom2EditText = findViewById(R.id.editTextSymptom2);
        EditText symptom3EditText = findViewById(R.id.editTextSymptom3);
        Button submitButton = findViewById(R.id.btnSubmit);
        TextView resultTextView = findViewById(R.id.textViewResult);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String symptom1 = getCorrectedText(symptom1EditText);
                String symptom2 = getCorrectedText(symptom2EditText);
                String symptom3 = getCorrectedText(symptom3EditText);

                String predictedDisease = predictDisease(symptom1, symptom2, symptom3);

                resultTextView.setText("The Predicted Disease: " + predictedDisease);
            }
        });
    }

    private String getCorrectedText(EditText editText) {
        String input = editText.getText().toString().toLowerCase();
        for (Map.Entry<String, String> entry : autoCorrectMap.entrySet()) {
            input = input.replaceAll("\\b" + entry.getKey() + "\\b", entry.getValue());
        }
        return input;
    }

    private String predictDisease(String symptom1, String symptom2, String symptom3) {
                List<String> diseases = Arrays.asList(
                        "Chickenpox: Itchy, rash, fever",
                        "Common cold: Runny nose, cough, sneezing",
                        "Diphtheria: Sore throat, fever, difficulty breathing",
                        "E. coli: Abdominal cramps, diarrhea, nausea",
                        "Giardiasis: Stomach cramps, bloating, diarrhea",
                        "HIV/AIDS: Fatigue, weight loss, night sweats",
                        "Influenza (flu): Fever, cough, body aches",
                        "Lyme disease: Skin rash, headache, joint pain",
                        "Malaria: Fever, chills, sweating",
                        "Measles: High fever, cough, rash",
                        "Meningitis: Severe headache, fever, stiff neck",
                        "Mumps: Swollen salivary glands, fever, headache",
                        "Pneumonia: Chest pain, fever, difficulty breathing",
                        "Rocky mountain spotted fever: Fever, headache, rash",
                        "Rubella (German measles): Mild, fever, rash",
                        "Salmonella infections: Abdominal cramps, diarrhea, vomiting",
                        "Tuberculosis: Cough, weight loss, night sweats",
                        "Viral hepatitis: Jaundice, abdominal pain, fatigue",
                        "West Nile virus: Fever, headache, body aches",
                        "Whooping cough (pertussis): Severe coughing, spells, whooping sound",
                        "Disease A: Symptom X, Symptom Y, Symptom Z",
                        "Disease B: Symptom P, Symptom Q, Symptom R",
                        "Disease C: Symptom M, Symptom N, Symptom O",
                        "Disease D: Symptom D, Symptom E, Symptom F",
                        "Disease E: Symptom G, Symptom H, Symptom I",
                        "Disease F: Symptom J, Symptom K, Symptom L",
                        "Disease G: Symptom U, Symptom V, Symptom W",
                        "Disease H: Symptom S, Symptom T, Symptom U",
                        "Disease I: Symptom X, Symptom Y, Symptom Z",
                        "Disease J: Symptom A, Symptom B, Symptom C",
                        "Disease K: Symptom M, Symptom N, Symptom O",
                        "Disease L: Symptom D, Symptom E, Symptom F",
                        "Disease M: Symptom G, Symptom H, Symptom I",
                        "Disease N: Symptom J, Symptom K, Symptom L",
                        "Disease O: Symptom U, Symptom V, Symptom W",
                        "Disease P: Symptom S, Symptom T, Symptom U",
                        "Disease Q: Symptom X, Symptom Y, Symptom Z",
                        "Disease R: Symptom A, Symptom B, Symptom C",
                        "Disease S: Symptom M, Symptom N, Symptom O",
                        "Disease T: Symptom D, Symptom E, Symptom F"
                );

        Map<String, Integer> matchingSymptomsCount = new HashMap<>();

        for (String disease : diseases) {
            String[] parts = disease.split(":");
            String diseaseName = parts[0].trim();
            String[] symptomsArray = parts[1].split(",");
            List<String> symptomsList = Arrays.asList(symptomsArray);

            int count = (int) symptomsList.stream()
                    .filter(symptom ->
                            symptomMatches(symptom, symptom1) ||
                                    symptomMatches(symptom, symptom2) ||
                                    symptomMatches(symptom, symptom3))
                    .count();

            matchingSymptomsCount.put(diseaseName, count);
        }

        String predictedDisease = getMostMatchingDisease(matchingSymptomsCount);

        return predictedDisease != null ? predictedDisease : "Unknown Disease";
    }

    private boolean symptomMatches(String symptom, String userSymptom) {
        return symptom.trim().equalsIgnoreCase(userSymptom.trim());
    }

    private String getMostMatchingDisease(Map<String, Integer> matchingSymptomsCount) {
        int maxCount = 0;
        String mostMatchingDisease = null;

        for (Map.Entry<String, Integer> entry : matchingSymptomsCount.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                mostMatchingDisease = entry.getKey();
            }
        }

        return mostMatchingDisease;
    }

    private Map<String, String> createAutoCorrectMap() {
        Map<String, String> map = new HashMap<>();
        map.put("symtom", "symptom");
        map.put("feaver", "fever");
        map.put("nausia", "nausea");
        map.put("diarrhea", "diarrhoea");
        map.put("diarhea", "diarrhoea");
        map.put("abdomnal", "abdominal");
        map.put("receving", "receiving");
        map.put("headake", "headache");
        map.put("fatige", "fatigue");
        map.put("weiht", "weight");
        map.put("loose", "lose");
        map.put("breething", "breathing");
        map.put("jaundise", "jaundice");
        map.put("musle", "muscle");
        map.put("stiffnes", "stiffness");
        map.put("paralisis", "paralysis");
        map.put("nausous", "nauseous");
        map.put("vomiting", "vomiting");
        map.put("diarea", "diarrhoea");
        map.put("sweating", "sweating");
        Map<String, String> caseInsensitiveMap = new HashMap<>();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            caseInsensitiveMap.put(entry.getKey().toLowerCase(), entry.getValue());
        }
        map.putAll(caseInsensitiveMap);

        return map;
    }
}
